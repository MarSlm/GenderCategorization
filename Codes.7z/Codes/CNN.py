# Import the necessary libraries
import tensorflow as tf
import numpy as np
# Is used for writing all np.arrays's cells in file
np.set_printoptions(threshold=np.nan)
import pickle
from PIL import Image
import random

# List of arrays with dimensions 300*300. These arrays represent images
t300x300 = []
# List of values that represent the classes of the images
# Values : male, female
classes300x300 = []
# List of transformed values that represent the classes of the images
# Values : 0, 1 respectively
classesBin = []
# List of arrays with dimensions 300*300. These arrays represent resized images
t100x100 = []

# Keeps the maximum value of Testing Accuracy
# Helps to keep only the prediction for the maximum value of Testing Accuracy
#t_acc_MAX =0

# List that contains indexes from t100x100 list.
# In these inedexes women exist
womenLabel = []
countWomen = 0
randomStart = 0

###################
### IMPORT DATA ###
###################

# Import images from the file
with open("C:/Users/Alexandra/Desktop/test.txt", "rb") as fp:
	t = pickle.load(fp)

# Import CLASSES from the file
with open("C:/Users/Alexandra/Desktop/y.txt", "rb") as fp:
	classes = pickle.load(fp)

#################################
### TRANSFORM / PROCESS DATA ###
#################################

# Keep only the images 300*300
# Respectively, keep the class of the image
for i in range(0, len(t)):
    if len(t[i]) == 300:
        if len(t[i][1]) == 300:
            t300x300.append(t[i])
            classes300x300.append(classes[i])

# Append in a list - classesBin -  values 0, 1 instead of 'male', 'female'
for i in range(0, len(classes300x300)):
    if  classes300x300[i] == 'male':
        classesBin.append(0)
    else:
        classesBin.append(1)

# Create hot vector using the binary list - classesBin
nb_classes = 2
targets = np.array([classesBin]).reshape(-1)
one_hot = np.eye(nb_classes)[targets]


print(len(t300x300))
# Images are kept in variable t300x300
# Variable t that used for initial loading is cleared for memory reasons
t=0

# Transform an image of size 300* 300 in an image of size 100*100
# First, the np.array of size 300*300 is converted in image
# After that the image is converted in np.array of size 100*100
for i in range(0, len(t300x300)):
    t300x300ToImage = Image.fromarray(t300x300[i], 'L')
    t100x100Image = t300x300ToImage.resize((100, 100), Image.ANTIALIAS)
    t100x100.append(np.asarray(t100x100Image, dtype=np.float32))

# Images are kept in variable t100x100
# Variable t300x300 is cleared for memory reasons
t300x300 = 0

############
### CNN ###
############

# Parameters
learning_rate = 0.001 # The pace that the model is trained
training_iters = 100000 # Number of iterations
batch_size =  128 # Size of images used for training / testing
display_step = 5 # Step of showing results
randomInBatch = int((2*batch_size)/3)
womenInBatch = int(batch_size - randomInBatch)

# Network Parameters
n_input = 10000 # data input (img shape: 100*100)
n_classes = 2 # total classes (man / woman)
dropout = 0.75 # Dropout, probability to keep units

# Store layers weight & bias
weights = {
    # 3x3 conv, 1 input, 32 outputs
    'wc1': tf.Variable(tf.random_normal([3, 3, 1, 32])),
    # 5x5 conv, 32 inputs, 64 outputs
    'wc2': tf.Variable(tf.random_normal([5, 5, 32, 64])),
    # 3x3 conv, 64 inputs, 128 outputs
    'wc3': tf.Variable(tf.random_normal([3, 3, 64, 128])),
    # 5x5 conv, 128 inputs, 256 outputs
    'wc4': tf.Variable(tf.random_normal([5, 5, 128, 256])),
    #'wc5': tf.Variable(tf.random_normal([3, 3, 256, 512])),
    #'wc6': tf.Variable(tf.random_normal([5, 5, 512, 1024])),
	#
    # fully connected, 7*7*256 inputs, 1024 outputs
    'wd1': tf.Variable(tf.random_normal([7*7*256, 1024])),
    # 1024 inputs, 2 outputs (class prediction)
    'out': tf.Variable(tf.random_normal([1024, n_classes]))
}

biases = {
    'bc1': tf.Variable(tf.random_normal([32])),
    'bc2': tf.Variable(tf.random_normal([64])),
    'bc3': tf.Variable(tf.random_normal([128])),
    'bc4': tf.Variable(tf.random_normal([256])),
    #'bc5': tf.Variable(tf.random_normal([512])),
    #'bc6': tf.Variable(tf.random_normal([1024])),
    'bd1': tf.Variable(tf.random_normal([1024])),
    'out': tf.Variable(tf.random_normal([n_classes]))
}


# tf Graph input
x = tf.placeholder(tf.float32, [None, 100, 100])
y = tf.placeholder(tf.float32, [None, n_classes])
keep_prob = tf.placeholder(tf.float32) #dropout (keep probability)

# Create some wrappers for simplicity
def conv2d(x, W, b, strides=1):
    # Conv2D wrapper, with bias and relu activation
    x = tf.nn.conv2d(x, W, strides=[1, strides, strides, 1], padding='SAME')
    x = tf.nn.bias_add(x, b)
    return tf.nn.relu(x)

def maxpool2d(x, k=2):
    # MaxPool2D wrapper
    return tf.nn.max_pool(x, ksize=[1, k, k, 1], strides=[1, k, k, 1], padding='SAME')

# Create model
def conv_net(x, weights, biases, dropout):
    # Reshape input picture
    x = tf.reshape(x, shape=[-1, 100, 100, 1])
    #
    # Convolution Layer 1
    conv1 = conv2d(x, weights['wc1'], biases['bc1'])
    # Max Pooling (down-sampling)
    conv1 = maxpool2d(conv1, k=2)
    #
    # Convolution Layer 2
    conv2 = conv2d(conv1, weights['wc2'], biases['bc2'])
    # Max Pooling (down-sampling)
    conv2 = maxpool2d(conv2, k=2)
    #
    # Convolution Layer 3
    conv3 = conv2d(conv2, weights['wc3'], biases['bc3'])
    conv3 = maxpool2d(conv3, k=2)
    #
    # Convolution Layer 4
    conv4 = conv2d(conv3, weights['wc4'], biases['bc4'])
    conv4 = maxpool2d(conv4, k=2)
    print( conv4.get_shape() )
	#
	# Convolution Layer 5
    #conv5 = conv2d(conv4, weights['wc5'], biases['bc5'])
    #conv5 = maxpool2d(conv5, k=2)
    #print( conv5.get_shape() )
	#
	# Convolution Layer 6
    #conv6 = conv2d(conv5, weights['wc6'], biases['bc6'])
    #conv6 = maxpool2d(conv6, k=2)
    #print( conv6.get_shape() )
    #
    # Fully connected layer
    # Reshape conv2 output to fit fully connected layer input
    fc1 = tf.reshape(conv4, [-1, 7*7*256])
    fc1 = tf.add(tf.matmul(fc1, weights['wd1']), biases['bd1'])
    fc1 = tf.nn.relu(fc1)
    # Apply Dropout
    fc1 = tf.nn.dropout(fc1, dropout)
    #
    # Output, class prediction
    out = tf.add(tf.matmul(fc1, weights['out']), biases['out'])
    return out


def next_batch(num, data, labels):
    '''
    Return a total of `num` random samples and labels.
    '''
    idx = np.arange(0 , len(data))
	# Shuffle data
    np.random.shuffle(idx)
	# Take the first 'randomInBatch' from the shuffled data
    idx = idx[:randomInBatch]
    data_shuffle = [data[ i] for i in idx]
    labels_shuffle = [labels[ i] for i in idx]
	# Return the shuffled data and their labels
    return np.asarray(data_shuffle), np.asarray(labels_shuffle)



def randomStart(womenInBatch):
    """
    Calculate the last point from which the model can select the last 'womenInBatch'
    women of the dataset
    """
    counter = 0
    randomPoint = 0
    randomPointList =[]

    for i in range((len(one_hot) -1), 0, -1):
        if counter == womenInBatch:
            randomPoint = i
            return randomPoint
        if one_hot[i,1] == 1:
            randomPointList.append(i)
            counter +=1
 
lastRandomPoint = randomStart(womenInBatch)           

# Construct model
pred = conv_net(x, weights, biases, keep_prob)

# Define loss and optimizer
cost = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(logits=pred, labels=y))
optimizer = tf.train.AdamOptimizer(learning_rate=learning_rate).minimize(cost)

# Evaluate model
correct_pred = tf.equal(tf.argmax(pred, 1), tf.argmax(y, 1))
accuracy = tf.reduce_mean(tf.cast(correct_pred, tf.float32))
prediction=tf.argmax(tf.argmax(pred, 1),1)

# Initializing the variables
init = tf.global_variables_initializer()

# Launch the graph
with tf.Session() as sess:
    sess.run(init)
    step = 1
    # Keep training until reach max iterations
    while step * batch_size < training_iters:
        batch_x, batch_y = next_batch(batch_size, t100x100, one_hot)

        # Random start is used for avoiding overfitting.
		# Each time that the batch is filled with women the start point is selected randomly
		# The random start point takes value from 0 - (len(images) - womenInBatch)
        randomStart = random.randint(0, lastRandomPoint) 

		# Iterations stop when the batch is filled with 'womenInBatch' number of women
        for i in range(randomStart, len(one_hot)):
            if countWomen == womenInBatch:
                countWomen = 0
                break

			# Keep the index of image when a woman is found
            if one_hot[i,1] == 1:
                womenLabel.append(i)
                countWomen +=1

		# Concatenate the random part of the batch with the one that includes women
		# Concatenate, respectively, the labels of the two parts in batch
        for j in range(0, len(womenLabel)):
            batch_x = np.concatenate((batch_x, t100x100[womenLabel[j]].reshape((1,100, -1))), axis = 0)
            batch_y = np.concatenate((batch_y, one_hot[womenLabel[j]].reshape((1, -1))), axis = 0)

        womenLabel = []

        # learning_rate = 0.001
        # Run optimization op (backprop)
        sess.run(optimizer, feed_dict={x: batch_x, y: batch_y, keep_prob: dropout})

        if step % display_step == 0:
            # Calculate batch loss and accuracy
            loss, acc = sess.run([cost, accuracy], feed_dict={x: batch_x, y: batch_y, keep_prob: 1.})
            # Calculate accuracy for 256 mnist test images
            t_acc = sess.run(accuracy, feed_dict={x: t100x100[:batch_size], y: one_hot[:batch_size], keep_prob: 1.})

			# Used for writing only the predictions with the highest test accuracy
            #if t_acc_MAX < t_acc:
            #t_acc_MAX = t_acc
            ################## write predictions in file ##################
			# Write in file what the model predict
            fp = open('C:/Users/Alexandra/Desktop/pred.txt', 'w')
            writeThePred = str((tf.argmax(pred, 1)).eval(feed_dict={x: t100x100[:batch_size],  keep_prob: 1.}))
            fp.write(writeThePred)
            fp.close()
			# Write in file the values of images' labels
            fp = open('C:/Users/Alexandra/Desktop/real.txt', 'w')
            writeReal = str((tf.argmax(one_hot[:batch_size], 1)).eval(feed_dict={x: batch_x, y: batch_y, keep_prob: 1.}))
            fp.write(writeReal)
            fp.close()
            ################################################################


            print(
                    "Iter " + str(step*batch_size) +
                    ", Learning Rate " + str(learning_rate) +
                    ", Minibatch Loss= " + "{:.6f}".format(loss) +
                    ", Training Accuracy= " + "{:.5f}".format(acc) +
                    ", Testing Accuracy= " + "{:.5f}".format(t_acc)
                    )
        step += 1
    print("Optimization Finished!")
