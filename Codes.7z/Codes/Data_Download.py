import numpy as np
import requests
from PIL import Image
from io import BytesIO
import csv
import pickle

# Delete spaces in the csv through notepad++
# Delete double commas (make them one)

#Splitting the rows of the file on the commas and saving them in the variable pic
pic = []
with open('C:/Users/gin_a/Downloads/a943287.csv', newline='') as csvfile:
    spamreader = csv.reader(csvfile, delimiter=' ', quotechar='|')
    for row in spamreader:
        pic.append(row[0].split(","))

#Transofrming pic into numpy array for each of processing and deleting the columns that are irrelevant.
pic = np.array(pic)
pic = np.delete(pic, 0)
for i in range(0, len(pic)):
    pic[i] = np.array(pic[i])
for i in range(0, len(pic)):
    pic[i] = np.delete(pic[i], [0, 1, 2, 3, 4, 6, 8, 9])

#Downloading the images in grey scale
img = []
y = []
for i in range(0, len(pic)):     # Iterating through all the rows
    if pic[i][0] != "unsure":    #Checking whether the class is unsure
        response = requests.get(pic[i][1])   #Requesting the image from the server
        if str(response) == "<Response [200]>":    #Checking whether the server responded.
            temp = Image.open(BytesIO(response.content))    #If the class is not unsure and the server responded, then
            temp = temp.convert("L")                        #take the image, transform it to grey scale and store it in img.
            img.append(np.asarray(temp))
            y.append(pic[i][0])                             #Also store the class of the image.
    if i % 1000 == 0:                       #Print the row number every 1000 rows to keep track of the progress.
        print(i)

# Export to a file
with open("C:/Users/gin_a/Desktop/Data/test.txt", "wb") as fp:
    pickle.dump(img, fp)

# Import from the file
with open("C:/Users/gin_a/Desktop/Data/test.txt", "rb") as fp:
    img = pickle.load(fp)