import tensorflow as tf
import matplotlib.pyplot as plt
import pickle
from PIL import Image
import numpy as np

#with open("C:/Users/Alexandra/Desktop/test.txt","rb") as fp:
with open("YourPath/test.txt","rb") as fp:
    images=pickle.load(fp)
    
#with open("C:/Users/Alexandra/Desktop/y.txt","rb") as fp:
with open("YourPath/y.txt","rb") as fp:
    labels = pickle.load(fp)
    
# the images and labels variables are lists, 
#so we convert the variables to array in our workspace  
img=np.array(images)

#print the images dimensions
print(img.ndim)
# Print the number of `images`'s elements
print(img.size)

# Print the first instance of `images`
#the images[0] is one single image that is represented by arrays in arrays! 
images[0]
img[0]

label=np.array(labels)

# Print the `labels` dimensions
print(label.ndim)
# Print the number of `labels`'s elements
print(label.size)
#count the number of classes
print(len(set(labels)))


image_signs=[29,78,40,98,769]

## Fill out the subplots with the random images and add shape, min and max values
for i in range(len(image_signs)):
    plt.subplot(1,5,i+1)
    plt.axis('off')
    plt.imshow(img[image_signs[i]])
    plt.subplots_adjust(wspace=0.5)
    
plt.show()

############

