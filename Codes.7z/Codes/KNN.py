from __future__ import print_function
import tensorflow as tf
import numpy as np
import pickle

#Images and classes loading from file
with open("C:/Users/gin_a/Desktop/Data/test.txt", "rb") as fp:
    im = pickle.load(fp)

with open("C:/Users/gin_a/Desktop/Data/y.txt", "rb") as fp:
    clas = pickle.load(fp)

img = []
classes = []

#Keeping only the images of size 300x300
for i in range(0, len(im)):
    if len(im[i]) == 300:
        if len(im[i][1]) == 300:
            img.append(im[i])
            classes.append(clas[i])

#Flattening the images
for i in range(0, len(img)-1):
	img[i] = np.hstack(img[i])

#Transforming the classes to one hot vectors
gender = []
for i in range(0,len(classes)-1):
	if classes[i] == 'male':
		gender.append([1, 0])
	else:
		gender.append([0, 1])

#Splitting the train and the test data
img_tr = img[0:49999]
img_te = img[50000:54391]
gender_tr = gender[0:49999]
gender_te = gender[50000:54391]

"""   This part of code is used when we want to get 13000 images for training - 6500 males and 6500 females.
img_new = []
gender_new = []
males = 0
females = 0
for i in range(len(img_tr)):
    if gender_tr[i] == [1,0]:
        if gender_new.count([1, 0]) == 2500:
            continue
        males = males + 1
    else:
        females = females + 1
    img_new.append(img_tr[i])
    gender_new.append(gender_tr[i])
    if gender_new.count([0,1]) == 2500:
        break

print(males)
print(females)
img_tr = img_new
gender_tr = gender_new
"""

#Taking the fisrt 5000 images as the training data set
Xtr = np.array(img_tr[0:5000])
Ytr = np.array(gender_tr[0:5000])

#Taking 100 images as the test set
Xte = np.array(img_te[0:99])
Yte = np.array(gender_te[0:99])

#Defining the placeholders, xtr and xte
xtr = tf.placeholder("float", [None, 90000])
xte = tf.placeholder("float", [90000])

#Defining the distance measure
distance = tf.reduce_sum(tf.abs(tf.add(xtr, tf.negative(xte))), reduction_indices=1)

#Defining the prediction, which is simply the calss from which the distance is minimum
pred = tf.arg_min(distance, 0)

#Initializing the accuracy
accuracy = 0.

#Initializing the variables of the graph
init = tf.global_variables_initializer()

#Running the session
with tf.Session() as sess:
    sess.run(init)
    # loop over test data
    for i in range(len(Xte)):
        # Get nearest neighbor
        nn_index = sess.run(
            pred,
            feed_dict={
                xtr: Xtr,
                xte: Xte[i, :]
            }
        )
        # Get nearest neighbor class label and compare it to its true label
        print("Test", i, "Prediction:", np.argmax(Ytr[nn_index]), "True Class:", np.argmax(Yte[i]))
        # Calculate accuracy
        if np.argmax(Ytr[nn_index]) == np.argmax(Yte[i]):
            accuracy += 1./len(Xte)
    print("Done!")
    print("Accuracy:", accuracy)

