import tensorflow as tf
import numpy as np
import pickle

#Images and classes loading from file
with open("C:/Users/gin_a/Desktop/Data/test.txt", "rb") as fp:
    im = pickle.load(fp)

with open("C:/Users/gin_a/Desktop/Data/y.txt", "rb") as fp:
    clas = pickle.load(fp)

img = []
classes = []

#Keeping only the images of size 300x300
for i in range(0, len(im)):
   if len(im[i]) == 300:
       if len(im[i][1]) == 300:
         img.append(im[i])
         classes.append(clas[i])

#Flattening the images
for i in range(0, len(img)):
	img[i] = np.hstack(img[i])

#Transforming the classes to one hot vectors
gender = []
for i in range(0,len(classes)):
	if classes[i] == 'male':
		gender.append([1, 0])
	else:
		gender.append([0, 1])

#Splitting the train and the test data
img_tr = img[0:49999]
img_te = img[50000:54391]
gender_tr = gender[0:49999]
gender_te = gender[50000:54391]

"""   This part of code is used when we want to get 13000 images for training - 6500 males and 6500 females.
img_new = []
gender_new = []
males = 0
females = 0
for i in range(len(img_tr)):
    if gender_tr[i] == [1,0]:
        if gender_new.count([1, 0]) == 6500:
            continue
        males = males + 1
    else:
        females = females + 1
    img_new.append(img_tr[i])
    gender_new.append(gender_tr[i])
    if gender_new.count([0,1]) == 6500:
        break

print(males)
print(females)
img_tr = img_new
gender_tr = gender_new
"""

#Defining the parameters
learning_rate = 0.00000000005
training_epochs = 1000
batch_size = 64
display_step = 1

#Defining the cost function
def categorical_cross_entropy_loss(y, pred):
    cost = tf.reduce_mean(-tf.reduce_sum(y * tf.log(pred), reduction_indices=1))
    return cost

#Defining the placeholders
x = tf.placeholder(tf.float32, [None, 90000])
y = tf.placeholder(tf.float32, [None, 2])

#Defining the weights and the biases
W = tf.Variable(tf.zeros([90000, 2]))
b = tf.Variable(tf.zeros([2]))

#Defining the prediction, which is the softmax of the multiplication of the weights with the input plus the biases.
pred = tf.nn.softmax(tf.matmul(x, W) + b)

cost = categorical_cross_entropy_loss(y, pred)

#Defining the optimizing method
optimizer = tf.train.GradientDescentOptimizer(learning_rate).minimize(cost)

#Defining when a prediction is correct
correct_prediction = tf.equal(tf.argmax(pred, 1), tf.argmax(y, 1))

#Defining the calculation of the accuracy
accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))

#Initializing the variables of the graph.
init = tf.global_variables_initializer()

#Running the session
with tf.Session() as sess:
    sess.run(init)
    epochs = []
    tr_acc = []
    test_acc = []
    costs = []
    for epoch in range(training_epochs):
        avg_cost = 0.
        avg_acc = 0.
        total_batch = int(len(img_tr) / batch_size)
        for i in range(total_batch):
            #Choosing random images for each batch.
            idx = np.arange(0, len(img_tr))
            np.random.shuffle(idx)
            idx = idx[:batch_size]
            batch_xs = [img_tr[i] for i in idx]
            batch_ys = [gender_tr[i] for i in idx]
            _, c, acc = sess.run(
                [
                    optimizer,
                    cost,
                    accuracy
                ],
                feed_dict={
                    x: batch_xs,
                    y: batch_ys
                }
            )
            avg_cost += c / total_batch
            avg_acc += acc / total_batch
        if (epoch + 1) % display_step == 0:
            tes_acc = sess.run(accuracy, feed_dict={
                x: img_te,
                y: gender_te
            })
            print(
                "Epoch: " + str('%04d' % (epoch + 1)) +
                " cost=" + "{:.9f}".format(avg_cost) +
                " train accuracy=" + "{:.9f}".format(avg_acc) +
                " test accuracy=" + "{:.9f}".format(tes_acc)
            )
            epochs.append(epoch + 1)
            tr_acc.append(avg_acc)
            test_acc.append(tes_acc)
            costs.append(avg_cost)
    print("Optimization Finished!")
