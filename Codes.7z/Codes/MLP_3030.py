import tensorflow as tf
import numpy as np
from PIL import Image
import pickle

#Images and classes loading from file
with open("C:/Users/gin_a/Desktop/Data/test.txt", "rb") as fp:
    im = pickle.load(fp)

with open("C:/Users/gin_a/Desktop/Data/y.txt", "rb") as fp:
    clas = pickle.load(fp)

img = []
classes = []

#Keeping only the images of size 300x300
for i in range(0, len(im)):
    if len(im[i]) == 300:
        if len(im[i][1]) == 300:
            img.append(im[i])
            classes.append(clas[i])
type(img)


#Transforming the classes to one hot vectors
gender = []
for i in range(0,len(classes)):
	if classes[i] == 'male':
		gender.append([1, 0])
	else:
		gender.append([0, 1])

imgsmall = []

#Transforming the image arrays from 300x300 to 30x30
for i in range(0, len(img)):
    imgToImage = Image.fromarray(img[i], 'L')
    imgsmallImage = imgToImage.resize((30, 30), Image.ANTIALIAS)
    imgsmall.append(np.asarray(imgsmallImage, dtype=np.float32))

img = imgsmall

#Flattening the images
for i in range(0, len(img)):
	img[i] = np.hstack(img[i])

#Splitting the train and the test data
img_tr = img[0:49999]
img_te = img[50000:54391]
gender_tr = gender[0:49999]
gender_te = gender[50000:54391]

# Parameters
learning_rate = 0.001
training_epochs = 100
batch_size = 100
display_step = 1

# Network Parameters
n_hidden_1 = 100 # 1st layer number of features
n_hidden_2 = 100 # 2nd layer number of features
n_hidden_3 = 100 # 3rd layer number of features
n_input = 900 # image data input (img shape: 30*30)
n_classes = 2 # total classes (2)

# tf Graph input
x = tf.placeholder("float", [None, n_input])
y = tf.placeholder("float", [None, n_classes])

#Defining the weights and the biases. They initialize randomly
weights = {
    'h1': tf.Variable(tf.random_normal([n_input, n_hidden_1])),
    'h2': tf.Variable(tf.random_normal([n_hidden_1, n_hidden_2])),
    'h3': tf.Variable(tf.random_normal([n_hidden_2, n_hidden_3])),
    'out': tf.Variable(tf.random_normal([n_hidden_3, n_classes]))
}
biases = {
    'b1': tf.Variable(tf.random_normal([n_hidden_1])),
    'b2': tf.Variable(tf.random_normal([n_hidden_2])),
    'b3': tf.Variable(tf.random_normal([n_hidden_3])),
    'out': tf.Variable(tf.random_normal([n_classes]))
}

#Defining the MLP
def multilayer_perceptron(x, weights, biases):
    # Hidden layer with RELU activation
    layer_1 = tf.add(tf.matmul(x, weights['h1']), biases['b1'])
    layer_1 = tf.nn.relu(layer_1)
    # Hidden layer with RELU activation
    layer_2 = tf.add(tf.matmul(layer_1, weights['h2']), biases['b2'])
    layer_2 = tf.nn.relu(layer_2)
    # Hidden layer with RELU activation
    layer_3 = tf.add(tf.matmul(layer_2, weights['h3']), biases['b3'])
    layer_3 = tf.nn.relu(layer_3)
    # Output layer with linear activation
    out_layer = tf.matmul(layer_3, weights['out']) + biases['out']
    return out_layer

# Construct model
pred = multilayer_perceptron(x, weights, biases)
# Test model
correct_prediction = tf.equal(tf.argmax(pred, 1), tf.argmax(y, 1))
# Calculate accuracy
accuracy = tf.reduce_mean(tf.cast(correct_prediction, "float"))

# Define loss and optimizer
cost = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(logits=pred, labels=y))
optimizer = tf.train.AdamOptimizer(learning_rate=learning_rate).minimize(cost)

# Initializing the variables
init = tf.global_variables_initializer()

# Launch the graph
with tf.Session() as sess:
    sess.run(init)
    # Training cycle
    for epoch in range(training_epochs):
        avg_cost = 0.
        avg_acc = 0.
        total_batch = int(len(img_tr) / batch_size)
        # Loop over all batches
        for i in range(total_batch):
            # Choosing random images for each batch.
            idx = np.arange(0, len(img_tr))
            np.random.shuffle(idx)
            idx = idx[:batch_size]
            batch_x = [img_tr[i] for i in idx]
            batch_y = [gender_tr[i] for i in idx]
            # Run optimization op (backprop) and cost op (to get loss value)
            _, c = sess.run([optimizer, cost], feed_dict={x: batch_x, y: batch_y})
            batch_acc = accuracy.eval({x: batch_x, y: batch_y})
            # Compute average loss
            avg_cost += c / total_batch
            avg_acc += batch_acc / total_batch
        # Display logs per epoch step
        if epoch % display_step == 0:
            test_acc = accuracy.eval({x: img_te, y: gender_te})
            print(
                "Epoch:",
                '%04d' % (epoch+1),
                "cost=",
                "{:.9f}".format(avg_cost),
                "average_train_accuracy=",
                "{:.6f}".format(avg_acc),
                "test_accuracy=",
                "{:.6f}".format(test_acc)
            )
    print("Optimization Finished!")
