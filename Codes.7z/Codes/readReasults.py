
predArray = []
countDiff = 0

# Import predictions AS pred from file
#with open("C:/Users/Alexandra/Desktop/pred.txt", "rb") as fp:
with open("YourPath/pred.txt", "rb") as fp:
    pred = fp.read()

pred = pred.decode("utf-8")
pred = pred.replace('\r\n', '')
pred = pred.replace('[', '')
pred = pred.replace(']', '')

for i in range(0, len(pred)):
    if pred[i] != ' ':
        predArray.append(pred[i])
        
realArray = []

# Import real values from dataset AS real from file
#with open("C:/Users/Alexandra/Desktop/real.txt", "rb") as fp:
with open("YouPath/real.txt", "rb") as fp:
	real = fp.read()

real = real.decode("utf-8")
real = real.replace('\r\n', '')
real = real.replace('[', '')
real = real.replace(']', '')

for i in range(0, len(real)):
    if real[i] != ' ':
        realArray.append(real[i])
        

# Find the indexes of women that the model predicted correctly 
for i in range(0, len(predArray)):
    for j in range(0, len(realArray)):
        if i == j:
            if predArray[i] == realArray[j]:
                if realArray[j] == '1':
                    print(str(str(i) + ' ' + str(predArray[i])) + ' ' + str(realArray[j]))

# Find differences between Real values and what the model predicted
for i in range(0, len(predArray)):
    for j in range(0, len(realArray)):
        if i == j:
            if predArray[i] != realArray[j]:
                print(str(str(i) + ' ' + str(predArray[i])) + ' ' + str(realArray[j]))
                countDiff +=1

print(str(countDiff))



 
