from PIL import Image
#import numpy as np
import pickle

#with open("C:/Users/Alexandra/Desktop/img.txt", "rb") as fp:
with open("YourPath/img.txt", "rb") as fp:
	t = pickle.load(fp)

img = Image.fromarray(t, 'L')

#img.save('C:/Users/Alexandra/Desktop/myTest.png')
img.save('YourPath/myImg.png')
img.show()


